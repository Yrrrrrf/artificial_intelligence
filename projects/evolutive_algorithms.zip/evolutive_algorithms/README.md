<h1 align="center">
    <img src="resources/img/puzzle.png" alt="Digital Strategy" width="240">
    <div align="center">Evolutive Algorithms</div>
</h1>

## Abstract

This is a implementation of some of the most used [Search Algorithms](./reports/00_main_report.ipynb) to solve the [pancake sorting problem](https://en.wikipedia.org/wiki/Pancake_sorting).

The main goal of this project is to compare the performance of the algorithms and to understand the differences between them.

NOTE: The project is still in development and the algorithms had been tested in the **[pancake sorting problem](https://en.wikipedia.org/wiki/Pancake_sorting)** (the algorithms will be tested in other problems in the future).

## Setup

- Create a virtual environment
```python
python -m venv .venv  # create a virtual environment
.venv\Scripts\activate  # activate the venv (Windows)
source .venv/bin/activate  # activate the venv (Linux)
```
- Install the dependencies
```python
python -m pip install --upgrade pip  # make sure you have the latest pip installed
pip install -r requirements.txt  # install the dependencies
```

- Run the project
```python
py src/main.py  # run main.py
```

## License

This project is licensed under the terms of the [MIT License](LICENSE.md).
