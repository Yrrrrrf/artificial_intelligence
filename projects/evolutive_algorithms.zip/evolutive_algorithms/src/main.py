"""
Main module for evolutive algorithms
This module contains the script that launch the GUI that shows the n-puzzle game. (TODO)

Author: Yrrrrrf
Date: Monday 13th, March 2023
"""


#? Imports ------------------------------------------------------------------------------------

# Own imports
import random
from config.globals import Config  # import config
from components.app import App  # import app class
# from components.n_puzzle import Puzzle  # import puzzle class

from components.pancake_sorting import *  # import pancake sorting animation

from test.unit_test import Test  # import test class


#? Logic --------------------------------------------------------------------------------------


def main() -> None:
    """
    Application entry point. 

    It is also responsible for setting up the logging system and configuring it.
    """
    # Once created, the app will run until the user closes the window
    app: App = App()  # create app instance
    app.run()  # run app


if __name__ == "__main__":
    """
    This is the entry point of the application.
    Clean the terminal and print app data before running the main function.
    """
    print("\033[2J\033[1;1H", end="")  # clear terminal
    print(f"\033[92m{Config.NAME.value}\033[0m", end=" ")  # print n puzzle solver in green
    print(f"\033[97m{Config.VERSION.value}\033[0m", end="\n\n")  # print version in white


    n: int = 4  # number of pancakes
    random_initial_state: list[int] = random.sample(range(1, n+1), n)  # generate random initial state
    # random_initial_state: list[int] = [5, 4, 3, 2, 1]
    dish: PancakeDish = PancakeDish(initial_state=random_initial_state)  # create pancake dish instance
    # dish: PancakeDish = PancakeDish(initial_state=[2, 3, 4, 1])  # create pancake dish instance
    # dish: PancakeDish = PancakeDish(initial_state=[10, 9, 8, 7, 6, 5, 4, 3, 2, 1])  # create pancake dish instance

    # ? Uninformative Search Algorithms
    dish.depth_first_search()  # look for all the possible solutions (not optimal)
    dish.depth_limited_search(limit=3)  # look for all the possible solutions with the same depth (not optimal)    
    dish.breadth_first_search()  # look for all the possible solutions with the same depth (not optimal)
    dish.uniform_cost_search()  # based on the cost of the path to reach the node

    # ? Informative Search Algorithms
    dish.heuristic_search()  # based on an efficient heuristic function
    dish.a_star_search()  # based on an efficient heuristic function and the cost of the path to reach the node

    # main()  # run main function
