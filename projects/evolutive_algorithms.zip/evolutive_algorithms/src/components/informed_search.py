import copy, heapq


class Pancakes:
	"""
	Pancakes class
	"""
	h_cost: int  # heuristic cost
	f_cost: int  # forward cost
	stack: list[int] = []  # stack of pancakes
	g_cost: int = 0  # cost to reach the current state

	def __init__(self, stack: list[int]):
		self.stack = stack
		# self.g_cost = 0
		self.h_cost = self.heuristic()
		self.f_cost = self.g_cost + self.h_cost

	def __lt__(self,other):
		"""
		Overload '<' operator for use in Priority Queue
		"""
		return self.f_cost < other.f_cost


	def print_st(self, done = False, initial = False):
		"""
		Prints the stack
		"""
		st = " ".join([str(i) for i in self.stack])
		if (done): print(("Final Stack:  " + st).rjust(31))
		elif(initial): print(("Initial Stack:  " + st).rjust(31))
		else: print(("Flip Stack:  "+ st).rjust(31))
			

	def goal_reached(self):
		"""
		Checks if we have reached the goal
		"""
		st = self.stack
		return all(st[i] >= st[i + 1] for i in range(len(st)-1))


	def flip(self, k: int):
		"""
		Flips the stack from 0 to k
		"""
		i = 0
		while(i < k):
			temp = self.stack[i]
			self.stack[i] = self.stack[k]
			self.stack[k] = temp
			k -= 1
			i += 1


	# Gap Heuristic -- used as the forward cost function
	def heuristic(self):
		"""
		Heuristic function
		
		This function calculates the number of gaps in the stack
		"""
		st: list[int] = self.stack
		h: int = 0
		for i in range(len(st)-1):  # for all pancakes in the stack
			if (abs(st[i+1] - st[i]) > 1): h += 1  # increment the heuristic cost if there is a gap
		return h  # return the heuristic cost


class PQ:
	"""
	Priority Queue Class
	
	This class implements a priority queue using a heap
	"""
	# heap: list[tuple[int, Pancakes]] = []  # heap of pancakes


	def __init__(self):
		self.heap = []

	def push(self, priority, value):
		"""
		Pushes a value onto the heap
		"""
		heapq.heappush(self.heap,(priority, value))
		

	def pop(self):
		"""
		Pops the lowest priority value from the heap
		"""
		return heapq.heappop(self.heap)


	def is_empty(self):
		"""
		Checks if the heap is empty
		"""
		return (len(self.heap) == 0)
	

def a_star(pancake_stack: Pancakes):
	"""
	A* Search

	### Parameters:
	- `pancake_stack`: Initial pancake stack
	"""
	frontier = PQ()  # Initialize the frontier
	frontier.push(pancake_stack.f_cost, pancake_stack)

	all_paths = {}
	all_paths[pancake_stack] = None

	visited = []  # Initialize list of visited nodes and their cost
	frontier_size = 0  # Initialize frontier size
	pancake_stack.print_st(initial = True)  # Print initial stack

	while(not frontier.is_empty()):  # Search through frontier
		curr = frontier.pop()[1]  # Get lowest cost pancake stack from frontier
		if(curr.goal_reached()):  # If we have found the solution then return it
			final = curr  # set final to the solution
			n_flips = curr.g_cost  # set number of flips to the solution
			path = [curr]  # set path to the solution
			while curr in all_paths:  # Gets path to solution
				curr = all_paths[curr]
				if(curr == None): break  # if we have reached the initial state then break
				path.append(curr)  # add the current state to the path
			path.reverse()  # reverse the path
			[i.print_st() for i in path[1:-1]]  # print all the flips
			path[-1].print_st(done=True)  # print the final stack
			return final, n_flips, frontier_size  # return the solution, number of flips, and frontier size

		for i in range(len(curr.stack)):  # For all possible flips, place them in the frontier
			frontier_stacks = [i[1] for i in frontier.heap]  # get all the stacks in the frontier
			flip_copy = copy.deepcopy(curr)  # copy the current stack
			flip_copy.flip(i)  # flip the stack from 0 to i
			flip_copy.g_cost += 1  # Update costs
			flip_copy.h_cost = flip_copy.heuristic()  # Update costs
			flip_copy.f_cost = flip_copy.g_cost + flip_copy.h_cost  # Update costs

			if(flip_copy in visited): continue  # if child is in visited then continue
			if (flip_copy not in frontier_stacks):  # if child is not in the frontier or visited then insert child in frontier
				all_paths[flip_copy] = curr  # add the parent of the child
				frontier.push(flip_copy.f_cost, flip_copy)  # add the child to the frontier
				frontier_size += 1  # increment the frontier size
			elif(flip_copy in frontier_stacks):  # if child is in the frontier then check if the cost is less than the current cost
				x = frontier_stacks.index(flip_copy)  # get the index of the child in the frontier
				curr_cost = frontier.heap[x][0]  # get the current cost of the child
				if(flip_copy.f_cost < curr_cost):  # if the cost of the child is less than the current cost then update the cost
					frontier.heap[x][0] = flip_copy.f_cost  # update the cost
					heapq.heapify(frontier)  # type: ignore  # heapify the frontier
		visited.append(curr)


def ucs(pancake_stack: Pancakes):
	"""
	Uniform Cost Search

	### Parameters:
	pancake_stack: Initial pancake stack
	"""
	frontier: PQ = PQ()  # Initialize the frontier
	frontier.push(pancake_stack.g_cost, pancake_stack)  # Push initial stack to frontier

	all_paths = {}  # stores the parent of each node
	all_paths[pancake_stack] = None  # stores the parent of each node
	visited = []  # Initialize list of visited nodes and their cost
	frontier_size: int = 0  # Initialize frontier size

	pancake_stack.print_st(initial = True)  # Prints initial stack

	while(not frontier.is_empty()):  # Search through frontier
		curr = frontier.pop()[1]  # Get lowest cost pancake stack from frontier

		if(curr.goal_reached()):  # If we have found the solution then return it
			final = curr  # set final to the solution
			n_flips = curr.g_cost  # set number of flips to the solution
			path = [curr]  # set path to the solution

			while curr in all_paths: # Gets path to solution
				curr = all_paths[curr]  # Gets parent of current node
				if(curr == None): break  # if we have reached the root node
				path.append(curr)  # Adds node to path
			path.reverse()  # Prints path to solution
			[i.print_st() for i in path[1:-1]]  # Prints all intermediate steps
			path[-1].print_st(done=True)  # Prints final step
			return final, n_flips, frontier_size  # Returns final stack, number of flips, and frontier size

		for i in range(len(curr.stack)):  # For all possible flips, place them in the frontier
			frontier_stacks = [i[1] for i in frontier.heap]  # Get all stacks in the frontier

			flip_copy = copy.deepcopy(curr)  # Create a copy of the current stack
			flip_copy.flip(i)  # Flip the copy
			flip_copy.g_cost += 1  # Update costs
			flip_copy.f_cost = flip_copy.g_cost  # Update costs

			if(flip_copy in visited): continue  # if child is already visited then skip
			if (flip_copy not in frontier_stacks):  # if child is not in the frontier or visited then insert child in frontier
				all_paths[flip_copy] = curr  # Add child to all_paths
				frontier.push(flip_copy.g_cost, flip_copy)  # Add child to frontier
				frontier_size += 1  # Update frontier size
			elif(flip_copy in frontier_stacks):  # if child is in frontier then update cost if necessary
				x = frontier_stacks.index(flip_copy)  # Get index of child in frontier
				curr_cost = frontier.heap[x][0]  # Get current cost of child
				if(flip_copy.f_cost < curr_cost):  # If new cost is less than current cost then update cost
					frontier.heap[x][0] = flip_copy.f_cost  # Update cost
					heapq.heapify(frontier)  # type: ignore  # Reorder frontier
		visited.append(curr)  # Add current node to visited


def greedy():
	"""
	Greedy Search
	"""
	print("\033[91m Greedy Search not implemented yet \033[0m")
