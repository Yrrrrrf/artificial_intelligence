# Pancake Sorting Pygame Animation
# the animathond will be a method that can be called by the app.py file

# ? Imports -----------------------------------------------------------------------------------

from dataclasses import dataclass
from collections import deque
import pygame

from config.globals import Config, Theme


# ? Logic -------------------------------------------------------------------------------------

# def pancake_sorting_animation(screen: pygame.Surface, algorithm: function=None, initial_state: list=None) -> None:
def pancake_sorting_animation(screen: pygame.Surface) -> None:
    """     
    This function animates the pancake sorting algorithm

    Draw the initial state of the pancakes
    Draw the final state of the pancakes
    Draw the current state of the pancakes

    Show the algorithm in action

    :param screen: pygame.Surface
    :param algorithm: function
    :param initial_state: list

    :return: None
    """
    PANCAKE_COLOR = (255, 165, 0)
    pancake_height: int = 32
    pancake_width: int = 64

    set_env(screen)  # set the environment (background, title, etc.)
    
    # initial_state: list = random.sample(range(1, 11), 10)
    initial_state: list = [5, 4, 3, 2, 1]

    for i in range(len(initial_state)):  # draw the current state of the pancakes
        pygame.draw.rect(screen, PANCAKE_COLOR, (Config.WIDTH.value // 2 - (pancake_width * initial_state[i]) // 2, Config.HEIGHT.value // 2 - (pancake_height * len(initial_state)) // 2 + (i * pancake_height), pancake_width * initial_state[i], pancake_height))
        # add the number of the pancake
        text = pygame.font.SysFont("Comic Sans", 24).render(str(initial_state[i]), True, Theme.TITLE.value)  # render the text
        screen.blit(text, (Config.WIDTH.value // 2 - (pancake_width * initial_state[i]) // 2 + (pancake_width * initial_state[i]) // 2 - text.get_width() // 2, Config.HEIGHT.value // 2 - (pancake_height * len(initial_state)) // 2 + (i * pancake_height) + pancake_height // 2 - text.get_height() // 2))


def set_env(screen: pygame.Surface) -> None:
    """
    Set the main Settings to run the any specific algorithm
    
    :param screen: pygame.Surface

    :return: None
    """
    #  draw the pancake icon on the left corner of the screen
    pygame.display.set_icon(pygame.image.load("resources/img/pancake.png"))

    # set background (kitchen img)
    background = pygame.image.load("resources/img/kitchen.jpg")
    background = pygame.transform.scale(background, (Config.WIDTH.value, Config.HEIGHT.value))
    screen.blit(background, (0, 0))

    # set the title
    text = Theme.TITLE_FONT.value.render("Pancake Sorting", True, Theme.TITLE.value)  # render the text
    screen.blit(text, (Config.WIDTH.value // 2 - text.get_width() // 2, 10))  # center the text


# ? Pancake Sorting Game Logic ----------------------------------------------------------------

@dataclass
class PancakeDish:
    """
    This class will be the dish where the pancakes will be placed
    """
    initial_state: list[int]  # the initial state of the pancakes
    current_state: list[int]  # the current state of the pancakes    
    final_state: list[int]  # the final state of the pancakes


    def __init__(self, initial_state: list[int]) -> None:
        """
        This function will initialize the class
        """
        self.initial_state = initial_state
        self.current_state = initial_state
        self.final_state = sorted(initial_state)


    def flip(self, index: int, log: bool = False) -> list[int]:
        """
        This function will flip the pancakes from the index to the top of the stack.
        Then print the current state of the pancakes

        ### Params:
        - `index`: int -> the index of the pancake to flip (must be in range)
        - `log`: bool -> if True, print the current state of the pancakes
        
        ### Returns:
        - `new_state`: list[int] -> the new state of the pancakes
        """
        if index > len(self.current_state): raise IndexError(f"Index out of range, \033[91mmax index must be {len(self.current_state)}\033[0m")  # check if the index is out of range
        self.current_state = self.current_state[:index][::-1] + self.current_state[index:]  # flip the pancakes
        if log: print(f"{self.current_state[:index][::-1] + self.current_state[index:]} -> \033[34m{self.current_state[:index]}\033[0m {self.current_state[index:]}")  # print current state
        return self.current_state


    def is_sorted(self) -> bool:
        """
        This function will check if the pancakes are sorted
        And print if the pancakes are sorted or not        

        ### Returns:
        - `sorted`: bool -> True if the pancakes are sorted, False otherwise
        """
        return self.current_state == self.final_state


    def print_sorted(self) -> None:
        """
        This function will print if the pancakes are sorted or not
        """
        print("Dish" , f"\033[92mis sorted\033[0m" if self.is_sorted() else f"\033[91misn't sorted\033[0m", f"    {self.current_state}")


    def heuristic_search(self):
        """
        `Euristic Search` is an algorithm that gets the k list of the indexes to `flip` the pancakes.
    
        This function will sort the pancakes using the Euristic Search algorithm
        Also return the number of steps to sort the pancakes and print the steps

        ### Returns:
        - `steps`: int -> the number of steps to sort the pancakes
        """
        k: list[int] = []  # k contains the indexes of the pancakes that are not sorted
        size: int = len(self.current_state)  # the size of the pancakes
        steps: int = 0  # the number of steps to sort the pancakes

        while not self.is_sorted():  # while the pancakes are not sorted
            for indx in range(size):  # for each pancake
                max_ = max(self.current_state[:size - indx])  # get the biggest pancake from the pancakes that are not sorted
                max_indx = self.current_state.index(max_) + 1  # get the index of the biggest pancake
                k.append(max_indx)  # add the index of the biggest pancake to the list of the indexes of the pancakes that are not sorted
                self.flip(max_indx, log=True)  # flip the pancakes from the index to the top of the stack
                steps += 1  # increment the number of steps
                self.current_state[:size - indx] = reversed(self.current_state[:size - indx])
                k.append(size - indx)
        print(f"Steps: {(steps)}")  # print the number of steps
        print(f"Flips: {(k)}")  # print the number of steps
        return k  # return the number of steps to sort the pancakes


# ? UNINFORMED SEARCH ALGORITHMS -----------------------------------------------------------


    def depth_first_search(self):
        """
        This function will sort the pancakes using the Depth First Search algorithm
        Also return the number of steps to sort the pancakes and print the steps
        """
        print(f"Initial state: {self.initial_state}")  # print the initial state of the pancakes

        stack: list = [self.initial_state]  # the stack of the pancakes
        explored: set = {tuple()}  # the set of the explored pancakes
        steps: int = 0  # the number of steps to sort the pancakes

        while stack and not self.is_sorted():  # while the stack is not empty
            v = stack.pop()  # get the last pancake
            explored.add(tuple(v))  # add the pancake to the explored pancakes
            for indx in range(2, len(self.initial_state) + 1):  # for each pancake
                # new_state = self.flip(indx, log=True)  # flip the pancake and add it to the stack
                # self.current_state = new_state
                self.current_state = v
                self.flip(indx, log=True)
                if tuple(self.current_state) not in explored:  # if the pancake is not explored
                    stack.append(self.current_state)  # add the pancake to the stack
                    steps += 1  # increment the number of steps
                if self.is_sorted(): break  # if the pancakes are sorted, break the loop
        print(f"Steps: {steps}")


    def depth_limited_search(self, limit: int = 2):
        """
        This function will sort the pancakes using the Depth Limited Search algorithm
        Also return the number of steps to sort the pancakes and print the steps

        ### Params:
        - `limit`: int -> the limit of the depth
        """
        print(f"Initial state: {self.initial_state}")

        stack: list = [self.initial_state]  # the stack of the pancakes
        explored: set = {tuple()}  # the set of the explored pancakes
        depth: int = 0  # the depth of the search

        while stack and not self.is_sorted():  # while the stack is not empty
            v = stack.pop()  # get the last pancake
            explored.add(tuple(v))  # add the pancake to the explored pancakes
            for indx in range(2, len(self.initial_state) + 1):  # for each pancake
                self.current_state = v
                self.flip(indx, log=True)
                if depth < limit:  # if the depth is less than the limit
                    if tuple(self.current_state) not in explored:  # if the pancake is not explored
                        stack.append(self.current_state)  # add the pancake to the stack
                    if self.is_sorted(): break  # if the pancakes are sorted, break the loop
                    depth += 1  # increment the depth
        print(f"Depth wasn't enough, depth: {depth}, limit: {limit}")
        # print(f"Steps: {steps}")


    def breadth_first_search(self):
        """
        This function will sort the pancakes using the Breadth First Search algorithm
        Also return the number of steps to sort the pancakes and print the steps
        """
        print(f"Initial state: {self.initial_state}")

        result: list = [self.initial_state]  # the result list (visited nodes)
        visited: set = {tuple(self.initial_state)}  # the set of the visited nodes
        queue = deque([self.initial_state])  # the queue of the nodes
        steps: int = 0  # the number of steps to sort the pancakes

        while queue and not self.is_sorted():
            v = queue.popleft()  # pop the first pancake from the queue
            for indx in range(2, len(self.initial_state) + 1):
                self.current_state = v
                self.flip(indx, log=True)
                if tuple(self.current_state) not in visited:  # if the new state is not visited
                    visited.add(tuple(self.current_state))  # add the new state to the visited nodes
                    result.append(self.current_state)  # add the new state to the result list
                    queue.append(self.current_state)  # add the new state to the queue
                    self.current_state = self.current_state  # set the new state as the current state
                    steps += 1
                    if self.is_sorted(): break
        print(f"Steps: {steps}")
        return result  # return the result list (visited nodes)
    
    
    def uniform_cost_search(self):
        """
        Uniform Cost Search algorithm

        This function will sort the pancakes using the Uniform Cost Search algorithm
        """
        # ! THE COMPLETE IMPLEMETATION OF THIS METHOD BECAME REALLY LARGE
        # ! SO I DECIDED TO MAKE A SEPARATE FILE FOR IT (informed_search.py)
        # ! AND IMPORT IT HERE
        print(f"Initial state: {self.initial_state}")
        from components.informed_search import Pancakes, ucs

        pancake_problem = Pancakes(self.initial_state)
        correct, flips, size = ucs(pancake_problem)  # type: ignore
        print(("Flips needed: "+ str (flips)).rjust(27))


# ? INFORMED SEARCH ALGORITHMS -----------------------------------------------------------


    def a_star_search(self):
        """
        A* Search algorithm

        This function will sort the pancakes using the A* Search algorithm
        """
        # ! THE COMPLETE IMPLEMETATION OF THIS METHOD BECAME REALLY LARGE
        # ! SO I DECIDED TO MAKE A SEPARATE FILE FOR IT (informed_search.py)
        # ! AND IMPORT IT HERE
        print(f"Initial state: {self.initial_state}")
        from components.informed_search import Pancakes, a_star  # import the astar function from the informed_search.py file

        pancake_problem = Pancakes(self.initial_state)
        correct, flips, size = a_star(pancake_problem)  # type: ignore
        print(("Flips needed: "+ str (flips)).rjust(27))
