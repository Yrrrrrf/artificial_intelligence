"""
Uninformed Search Algorithms

Uninformed search algorithms are a subclass of the general search algorithms.
They do not use any heuristics to guide the search towards the goal state.
They are less efficient than informed search algorithms.

- Breadth First Search
- Depth First Search
- Iterative Deepening Depth First Search
- Uniform Cost Search
- Depth Limited Search
- Iterative Deepening Depth Limited Search
- Bidirectional Search
- Bidirectional Depth Limited Search
- Iterative Deepening Bidirectional Search
- Iterative Deepening Bidirectional Depth Limited Search
- Iterative Deepening A* Search
"""


# ? Imports -------------------------------------------------------------------------------------------------------------------
# Python Imports
from collections import deque
from queue import Queue
from timeit import timeit  # for timing the algorithms

# Project Imports
# from test.performance import performance  # import performance decorator

# ? Logic ---------------------------------------------------------------------------------------------------------------------


# @performance  # print the time it took to execute the function
def depth_first_search(graph: dict, start: str) -> set:
    """
    Implementation of depth first search using collection.deque.
    
    ### Differences from BFS:
    1) pop last element instead of first one
    2) add adjacent elements to stack without exploring them
    3) add explored nodes to explored set
    4) return explored set instead of solution
    """
    explored: set = set(start)  # set of explored nodes
    stack: list = [start]  # use list as a stack

    while stack:  # while stack is not empty
        v = stack.pop()  # pop last element
        explored.add(v)  # add to explored nodes
        for adj in reversed(graph[v]):  # for each adjacent node
            if adj not in explored:  # if not explored
                stack.append(adj)  # add to stack
    return explored  # return the explored nodes


# @performance  # print the time it took to execute the function
def depth_limited_search(graph: dict, start: str, limit: int = 2) -> list[str]:
    """
    Depth Limited Search algorithm
    """
    visited = {start}  # set of visited nodes
    result = [start]  # list of visited nodes
    stack = [start]  # stack of visited nodes
    while stack:  # while stack is not empty
        v = stack.pop()  # get the last node from the stack
        if len(result) > limit:  # if the limit is reached
            return result  # return the result list (visited nodes)
        for child in graph[v]:  # for each child of the node
            if child not in visited:  # if child is not visited
                visited.add(child)  # mark child as visited
                result.append(child)  # add child to the result
                stack.append(child)  # add child to the stack
    return result  # return the result list (visited nodes)


# @performance  # print the time it took to execute the function
def iterative_deepening_search(graph: dict, start: str, goal: str = 'D') -> list[str]:
    """
    Iterative Deepening Search algorithm
    """
    for depth in range(0, len(graph)):  # for each depth
        result = depth_limited_search(graph, start, depth)  # search for the goal
        if result[-1] == goal:  # if the goal is found
            return result  # return the result list (visited nodes)
    return []  # return empty list if the goal is not found


# @performance  # print the time it took to execute the function
def recursive_dls(graph: dict, start: str, goal: str, limit: int) -> list[str]:
    """
    Recursive Depth Limited Search algorithm
    """
    visited = {start}  # set of visited nodes
    result = [start]  # list of visited nodes
    if start == goal:  # if the goal is found
        return result  # return the result list (visited nodes)
    elif limit == 0:  # if the limit is reached
        return []  # return empty list
    else:
        for child in graph[start]:  # for each child of the node
            if child not in visited:  # if child is not visited
                visited.add(child)  # mark child as visited
                result.append(child)  # add child to the result
                result = recursive_dls(graph, child, goal, limit - 1)  # search for the goal
                if result:  # if the goal is found
                    return result  # return the result list (visited nodes)
    return []  # return empty list if the goal is not found


# @performance  # print the time it took to execute the function
def breadth_first_search(graph: dict, start: str) -> list[str]:
    """
    Breadth First Search algorithm
    """
    visited = {start}  # set of visited nodes
    result = [start]  # list of visited nodes
    queue = Queue()  # queue of visited nodes
    queue.put(start)  # add start node to the queue
    while not queue.empty():  # while queue is not empty
        v = queue.get()  # get the first node from the queue
        for child in graph[v]:  # for each child of the node
            if child not in visited:  # if child is not visited
                visited.add(child)  # mark child as visited
                result.append(child)  # add child to the result
                queue.put(child)  # add child to the queue
    return result  # return the result list (visited nodes)


# ? Main ----------------------------------------------------------------------------------------------------------------------


def main():
    """
    Test the Uninformed Search Algorithms
    """
    G = {  # test graph
        "A": ["B", "C"],
        "B": ["A", "D", "E"],
        "C": ["A", "F"],
        "D": ["B"],
        "E": ["B", "F"],
        "F": ["C", "E"],
    }
    print("\nTest Uninformed Search Algorithms\n")

    print("Depth First Search:", depth_first_search(G, "A"), "\n")
    print("Breadth First Search:", breadth_first_search(G, "F"), "\n")
    print("Depth Limited Search:", depth_limited_search(G, "F"), "\n")
    # print("Iterative Deepening Search:", iterative_deepening_search(G, "F"))
    # print("Recursive Depth Limited Search:", recursive_dls(G, "A", "F", 2))

