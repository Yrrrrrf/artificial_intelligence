"""
App module

This module contains the script that launch the GUI that shows the n-puzzle game.
"""

#? Imports ------------------------------------------------------------------------------------

# Python imports
import pygame
import random
import time
from dataclasses import dataclass  # dataclass decorator

# Own imports
from config.globals import Config, Theme
from components.informed_search import *  # import informed search algorithms
from components.uninformed_search import *  #  import uninformed search algorithms

# Animations
from components.pancake_sorting import pancake_sorting_animation  # import pancake sorting animation

# todo:
#  from components.snake_game import snake_game_animation  # import snake game animation
# from components.hanoi_tower import hanoi_tower_animation  # import tower of hanoi animation
# from components.maze_generation import maze_generation_animation  # import maze generation animation
# from components.maze_solver import maze_solver_animation  # import maze solver animation
# from components.n_puzzle import n_puzzle_animation  # import n-puzzle animation
#


#? Logic --------------------------------------------------------------------------------------


#  create app class
@dataclass
class App:
    """
    App class
    This class contains the logic for the GUI
    """
    # App data (App State)
    screen: pygame.Surface
    running: bool = True
    play: bool = True


    def __init__(self) -> None:
        """
        Initialize the app
        """
        # print "App Running" on blue text
        print(f"\033[94mApp Running\033[0m")

    

    def run(self) -> None:
        """
        Pop up the window and run the app while the user doesn't close the window
        """
        pygame.init()  # initialize pygame
        self.screen = pygame.display.set_mode((Config.WIDTH.value, Config.HEIGHT.value))  # set window size
        pygame.display.set_caption(f"{Config.NAME.value} {Config.VERSION.value}")  # set window title
        # pygame.display.set_mode((Config.WIDTH.value, Config.HEIGHT.value), pygame.RESIZABLE)
        pygame.display.set_icon(pygame.image.load("resources/img/puzzle.png"))

        self.clock = pygame.time.Clock()  # Initialize the clock

        # SELECT THE ALGORITHM
        selected_algorithm = "Pancake Sorting"
        # selected_algorithm = "_"
        print(selected_algorithm)

        while self.running:  # while the app is running
            self.clock.tick(60)  # set the fps to 60
            # self.clock.tick(1)  # set the fps to 60

            for event in pygame.event.get():  # get all events
                if event.type == pygame.QUIT:  # if the user clicks the close button
                    pygame.quit()  # quit pygame
                    exit()  # exit the program
            if self.play:  # if the game is running
                self.screen.fill(Theme.BACKGROUND.value)  # fill the screen with the background color

                # font = pygame.font.Font("resources/fonts/CascadiaCodeItalic.ttf", 32)

                # now the same but using a switch statement
                match (selected_algorithm):
                    case "Pancake Sorting":
                        pancake_sorting_animation(self.screen)  # render the pancake sorting animation
                    # case "Snake Game":
                    #     snake_game_animation(self.screen)  # render the snake game animation
                    #     break
                    # case "Tower of Hanoi":
                    #     hanoi_tower_animation(self.screen)  # render the tower of hanoi animation
                    #     break
                    # case "Maze Generation":
                    #     maze_generation_animation(self.screen)  # render the maze generation animation
                    #     break
                    # case "Maze Solver":
                    #     maze_solver_animation(self.screen)  # render the maze solver animation
                    #     break
                    # case "N-Puzzle":
                    #     n_puzzle_animation(self.screen)  # render the n-puzzle animation
                    #     break
                    case _:  # Any other case
                        text = Theme.TITLE_FONT.value.render("Evolutive Algorithms", True, Theme.TITLE.value)  # render the text
                        self.screen.blit(text, (Config.WIDTH.value // 2 - text.get_width() // 2, 10))  # center the text
                        print(f"\033[91m{selected_algorithm} is not implemented\033[0m")

            pygame.display.update()  # update the display

