from time import time


def performance(func):
    '''
    Print the time it took to execute the function
    '''
    # def wrap_func(*args, **kwargs):  # Define a function that will be executed before the function that is decorated
    #     t1 = time()  # Get the time before the function is executed
    #     result = func(*args, **kwargs)  # Execute the function
    #     ex_time = time() - t1  # Get the time after the function is executed
    #     print(f'{func.__name__} took {ex_time:.10f} s\n')  # Print the time it took to execute the function
    #     return result  # Return the result of the function

    
    def wrap_func(*args, **kwargs):  # Define a function that will be executed before the function that is decorated
    # def a function that executes before the function n times and print the average time it took to execute the function
        ex_time = 0  # Initialize the execution time
        n: int = 10000
        result = None
        for i in range(0, n):  # For each iteration
            t1 = time()  # Get the time before the function is executed
            result = func(*args, **kwargs)  # Execute the function
            ex_time += time() - t1  # Get the time after the function is executed
        print(f'{func.__name__} took {ex_time / 10:.10f} s')  # Print the time it took to execute the function
        return result  # Return the result of the function
    return wrap_func  # Return the wrap_func function

